//package com.healthclinic.main;
//
//
//
//import java.util.Scanner;
//import com.healthclinic.dao.DoctorDAO;
//import com.healthclinic.model.Doctor;
//
//public class DoctorMain {
//
//    public static void main(String[] args) {
//
//        Scanner sc = new Scanner(System.in);
//        DoctorDAO dao = new DoctorDAO();
//
//        try {
//            while (true) {
//
//                System.out.println("\n===== Doctor Management =====");
//                System.out.println("1. Add Doctor");
//                System.out.println("2. Update Doctor Specialty");
//                System.out.println("3. View Doctors by Specialty");
//                System.out.println("4. Deactivate Doctor");
//                System.out.println("5. Exit");
//                System.out.print("Choose option: ");
//
//                int choice = Integer.parseInt(sc.nextLine());
//
//                switch (choice) {
//
//                    case 1:
//                        Doctor doctor = new Doctor();
//
//                        dao.showSpecialties();
//
//                        System.out.print("Enter Name: ");
//                        doctor.setName(sc.nextLine());
//
//                        System.out.print("Enter Contact: ");
//                        doctor.setContact(sc.nextLine());
//
//                        System.out.print("Enter Fee: ");
//                        doctor.setConsultationFee(Double.parseDouble(sc.nextLine()));
//
//                        System.out.print("Enter Specialty ID: ");
//                        doctor.setSpecialtyId(Integer.parseInt(sc.nextLine()));
//
//                        dao.addDoctor(doctor);
//                        break;
//
//                    case 2:
//                        System.out.print("Enter Doctor ID: ");
//                        int docId = Integer.parseInt(sc.nextLine());
//
//                        dao.showSpecialties();
//                        System.out.print("Enter New Specialty ID: ");
//                        int spId = Integer.parseInt(sc.nextLine());
//
//                        dao.updateDoctorSpecialty(docId, spId);
//                        break;
//
//                    case 3:
//                        dao.showSpecialties();
//                        System.out.print("Enter Specialty Name: ");
//                        String name = sc.nextLine();
//
//                        dao.viewDoctorsBySpecialty(name);
//                        break;
//
//                    case 4:
//                        System.out.print("Enter Doctor ID: ");
//                        int deactivateId = Integer.parseInt(sc.nextLine());
//
//                        dao.deactivateDoctor(deactivateId);
//                        break;
//
//                    case 5:
//                        System.out.println("Exiting...");
//                        return;
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}
package com.healthclinic.main;

import java.util.Scanner;
import com.healthclinic.dao.DoctorDAO;
import com.healthclinic.model.Doctor;

public class DoctorMain {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        DoctorDAO dao = new DoctorDAO();

        while (true) {

            try {
                System.out.println("\n----DOCTOR MANAGEMENT----");
                System.out.println("1. Add Doctor");
                System.out.println("2. Update Doctor Specialty");
                System.out.println("3. View Doctors by Specialty");
                System.out.println("4. Deactivate Doctor");
                System.out.println("5. Exit");
                System.out.println("Choose option:");

                int choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {

                    case 1:
                        Doctor d = new Doctor();

                        System.out.println("Enter Name:");
                        d.setName(sc.nextLine());

                        System.out.println("Enter Contact:");
                        d.setContact(sc.nextLine());

                        System.out.println("Enter Consultation Fee:");
                        d.setConsultationFee(sc.nextDouble());

                        dao.showSpecialties();
                        System.out.println("Enter Specialty ID:");
                        d.setSpecialtyId(sc.nextInt());

                        dao.addDoctor(d);
                        break;

                    case 2:
                        System.out.println("Enter Doctor ID:");
                        int docId = sc.nextInt();

                        dao.showSpecialties();
                        System.out.println("Enter New Specialty ID:");
                        int specId = sc.nextInt();

                        dao.updateDoctorSpecialty(docId, specId);
                        break;

                    case 3:
                        dao.showSpecialties();
                        System.out.println("Enter Specialty ID:");
                        int specialtyId = sc.nextInt();

                        dao.viewDoctorsBySpecialty(specialtyId);
                        break;

                    case 4:
                        System.out.println("Enter Doctor ID:");
                        int doctorId = sc.nextInt();

                        dao.deactivateDoctor(doctorId);
                        break;

                    case 5:
                        System.out.println("Exiting...");
                        sc.close();
                        System.exit(0);
                        break;

                    default:
                        System.out.println("Invalid Option!");
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
