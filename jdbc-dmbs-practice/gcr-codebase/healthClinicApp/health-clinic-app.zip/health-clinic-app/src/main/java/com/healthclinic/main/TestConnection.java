package com.healthclinic.main;

public class TestConnection {
}
