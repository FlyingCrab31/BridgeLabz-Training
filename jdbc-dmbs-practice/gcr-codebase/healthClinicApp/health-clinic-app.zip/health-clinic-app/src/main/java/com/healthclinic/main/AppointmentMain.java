package com.healthclinic.main;



import java.sql.Date;
import java.sql.Time;
import java.util.Scanner;
import com.healthclinic.dao.AppointmentDAO;

public class AppointmentMain {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        AppointmentDAO dao = new AppointmentDAO();

        try {
            while (true) {

                System.out.println("\n----Appointment Scheduling----");
                System.out.println("1. Book Appointment");
                System.out.println("2. Check Doctor Availability");
                System.out.println("3. Cancel Appointment");
                System.out.println("4. Reschedule Appointment");
                System.out.println("5. View Daily Schedule");
                System.out.println("6. Exit");
                System.out.print("Choose option: ");

                int choice = Integer.parseInt(sc.nextLine());

                switch (choice) {

                    case 1:
                        System.out.print("Enter Patient ID: ");
                        int pid = Integer.parseInt(sc.nextLine());

                        System.out.print("Enter Doctor ID: ");
                        int did = Integer.parseInt(sc.nextLine());

                        System.out.print("Enter Date (yyyy-mm-dd): ");
                        Date date = Date.valueOf(sc.nextLine());

                        System.out.print("Enter Time (HH:mm:ss): ");
                        Time time = Time.valueOf(sc.nextLine());

                        dao.bookAppointment(pid, did, date, time);
                        break;

                    case 2:
                        System.out.print("Enter Doctor ID: ");
                        int docId = Integer.parseInt(sc.nextLine());

                        System.out.print("Enter Date (yyyy-mm-dd): ");
                        Date d = Date.valueOf(sc.nextLine());

                        dao.checkAvailability(docId, d);
                        break;

                    case 3:
                        System.out.print("Enter Appointment ID: ");
                        dao.cancelAppointment(Integer.parseInt(sc.nextLine()));
                        break;

                    case 4:
                        System.out.print("Enter Appointment ID: ");
                        int apId = Integer.parseInt(sc.nextLine());

                        System.out.print("Enter New Date (yyyy-mm-dd): ");
                        Date newDate = Date.valueOf(sc.nextLine());

                        System.out.print("Enter New Time (HH:mm:ss): ");
                        Time newTime = Time.valueOf(sc.nextLine());

                        dao.rescheduleAppointment(apId, newDate, newTime);
                        break;

                    case 5:
                        System.out.print("Enter Date (yyyy-mm-dd): ");
                        dao.viewDailySchedule(Date.valueOf(sc.nextLine()));
                        break;

                    case 6:
                        return;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
