package com.healthclinic.main;

import java.sql.Date;
import java.util.Scanner;
import com.healthclinic.dao.PatientDAO;
import com.healthclinic.model.Patient;

public class MainApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        PatientDAO dao = new PatientDAO();

        while (true) {

            try {

                System.out.println("\n-----Patient Management-----");
                System.out.println("1. Register Patient");
                System.out.println("2. Update Patient");
                System.out.println("3. Search Patient by Name");
                System.out.println("4. View Visit History");
                System.out.println("5. Exit");
                System.out.print("Choose option: ");

                int choice = sc.nextInt();
                sc.nextLine(); // newline consume

                switch (choice) {

                    case 1:
                        Patient p = new Patient();

                        System.out.print("Enter Name: ");
                        p.setName(sc.nextLine());

                        System.out.print("Enter DOB (yyyy-mm-dd): ");
                        p.setDob(Date.valueOf(sc.nextLine()));

                        System.out.print("Enter Phone: ");
                        p.setPhone(sc.nextLine());

                        System.out.print("Enter Email: ");
                        p.setEmail(sc.nextLine());

                        System.out.print("Enter Address: ");
                        p.setAddress(sc.nextLine());

                        System.out.print("Enter Blood Group: ");
                        p.setBloodGroup(sc.nextLine());

                        dao.registerPatient(p);
                        break;

                    case 2:
                        System.out.print("Enter Patient ID or Phone: ");
                        String input = sc.nextLine();

                        Patient existing = dao.findPatient(input);

                        if (existing == null) {
                            System.out.println("Patient not found!");
                            break;
                        }

                        System.out.println("Current Name: " + existing.getName());
                        System.out.print("Enter New Name: ");
                        existing.setName(sc.nextLine());

                        dao.updatePatient(existing);
                        break;

                    case 3:
                        System.out.print("Enter Name to search: ");
                        dao.searchByName(sc.nextLine());
                        break;

                    case 4:
                        System.out.print("Enter Patient ID: ");
                        int id = sc.nextInt();
                        sc.nextLine();
                        dao.viewVisitHistory(id);
                        break;

                    case 5:
                        System.out.println("Exiting Patient Module...");
                        sc.close();
                        return; // program close

                    default:
                        System.out.println("Invalid choice! Try again.");
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
