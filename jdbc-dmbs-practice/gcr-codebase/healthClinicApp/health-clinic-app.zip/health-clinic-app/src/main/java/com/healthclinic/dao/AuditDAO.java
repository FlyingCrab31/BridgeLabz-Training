package com.healthclinic.dao;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.healthclinic.config.DBConnection;
import com.healthclinic.model.AuditLog;

public class AuditDAO {

    public List<AuditLog> getAuditLogs(String tableName, String userFilter) throws Exception {
        List<AuditLog> list = new ArrayList<>();
        String sql = "SELECT * FROM appointment_audit WHERE 1=1";
        if (tableName != null && !tableName.isEmpty()) {
            sql += " AND remarks LIKE ?";
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            if (tableName != null && !tableName.isEmpty()) {
                ps.setString(1, "%" + tableName + "%");
            }

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                AuditLog log = new AuditLog();
                log.setAuditId(rs.getInt("audit_id"));
                log.setAppointmentId(rs.getInt("appointment_id"));
                log.setActionType(rs.getString("action_type"));
                log.setRemarks(rs.getString("remarks"));
                log.setActionTime(rs.getTimestamp("action_time"));
                list.add(log);
            }
        }
        return list;
    }
}
